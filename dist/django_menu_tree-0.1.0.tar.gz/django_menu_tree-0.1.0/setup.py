# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['django_menu_tree',
 'django_menu_tree.migrations',
 'django_menu_tree.templatetags']

package_data = \
{'': ['*'],
 'django_menu_tree': ['static/django_menu_tree/*',
                      'templates/django_menu_tree/*']}

install_requires = \
['django>=4.1.7,<5.0.0']

setup_kwargs = {
    'name': 'django-menu-tree',
    'version': '0.1.0',
    'description': 'Django app for creating menus',
    'long_description': '=====\nDjango-menu-tree\n=====\n\nDjango-menu-tree is a Django app for creating menus and storing them in a database.\nIt allows you to retrieve the entire tree menu in one query to the database.\n\n\nQuick start\n-----------\n\n1. Add "django_menu_tree" to your INSTALLED_APPS setting like this:\n\n    INSTALLED_APPS = [\n        ...\n        \'django_menu_tree\',\n    ]\n\n2. Create a template, for example, a base template in your root:\n\n    `templates/base.html` \n\n    If you have created such a structure you also need update settings.py in your TEMPLATES variable:\n\n    `\'DIRS\': [\'templates\'],`\n\n3. Include the django_menu_tree URLconf in your project-level urls.py like this:\n\n    `from django_menu_tree.views import MenuView`\n\n    `path(\'category/<int:pk>/\', MenuView.as_view(template_name=\'base.html\'), name=\'menu\'),`\n\n4. Add the following to your templates/base.html like this:\n\n    `{% load menus %}`\n\n    `{% draw_menu menu_name=\'*name of menu*\' named_url=\'menu\' %}`\n\n    `{% block content %}{% endblock %}` _(if you use base template)_\n\n    named_url is optional if you only use custom urls in menu.\n    You can use `app_name:named_url` format.\n\n4. Run ``python manage.py migrate`` to create the models.\n\n5. Start the development server and visit http://127.0.0.1:8000/admin/\n   to create a menus (you\'ll need the Admin app enabled).\n\n5. Visit http://127.0.0.1:8000/category/<int:pk>/ to view menu tree.',
    'author': 'Mikhail Fedorov',
    'author_email': 'mikhailfedorov1939@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
